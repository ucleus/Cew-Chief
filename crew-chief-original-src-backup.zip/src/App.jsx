import { useEffect, useState } from "react";
import Icon from "./components/ui/Icon";
import SessionModal from "./components/session/SessionModal";
import Dashboard from "./screens/Dashboard";
import HistoryScreen from "./screens/HistoryScreen";
import LoginScreen from "./screens/LoginScreen";
import SettingsScreen from "./screens/SettingsScreen";
import SetupScreen from "./screens/SetupScreen";
import { S } from "./styles/theme";

export default function App() {
  const [screen, setScreen] = useState("login");
  const [activeTab, setActiveTab] = useState("dashboard");
  const [rider, setRider] = useState(null);
  const [settings, setSettings] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [showSessionModal, setShowSessionModal] = useState(false);

  useEffect(() => {
    try {
      const s = localStorage.getItem("mgp_settings");
      if (s) setSettings(JSON.parse(s));
      const sess = localStorage.getItem("mgp_sessions");
      if (sess) setSessions(JSON.parse(sess));
    } catch {}
  }, []);

  const handleLogin = (riderData) => {
    setRider(riderData);
    setScreen("app");
  };

  const handleSaveSettings = (s) => {
    const merged = { ...s, riderName: rider?.name };
    setSettings(merged);
    localStorage.setItem("mgp_settings", JSON.stringify(merged));
    setActiveTab("dashboard");
  };

  const handleSaveSession = (session) => {
    const updated = [...sessions, session];
    setSessions(updated);
    localStorage.setItem("mgp_sessions", JSON.stringify(updated));
  };

  const tabs = [
    { id: "dashboard", label: "Dashboard", icon: "dashboard" },
    { id: "setup", label: "Setup", icon: "wrench" },
    { id: "history", label: "History", icon: "chart" },
    { id: "settings", label: "Settings", icon: "settings" },
  ];

  if (screen === "login") return <LoginScreen onLogin={handleLogin} />;

  return (
    <div style={S.app}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;600&display=swap');
        * { box-sizing: border-box; }
        body { margin: 0; background: #0A0A0F; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: #0A0A0F; }
        ::-webkit-scrollbar-thumb { background: rgba(232,0,29,0.3); border-radius: 2px; }
        input:focus, select:focus, textarea:focus { border-color: #E8001D !important; outline: none; box-shadow: 0 0 0 2px rgba(232,0,29,0.12); }
        button:active { transform: scale(0.97); }
      `}</style>

      {/* Background */}
      <div
        style={{
          position: "fixed",
          inset: 0,
          backgroundImage:
            "linear-gradient(rgba(232,0,29,0.02) 1px,transparent 1px),linear-gradient(90deg,rgba(232,0,29,0.02) 1px,transparent 1px)",
          backgroundSize: "48px 48px",
          pointerEvents: "none",
        }}
      />

      {/* Header */}
      <div
        style={{
          position: "sticky",
          top: 0,
          zIndex: 50,
          background: "rgba(10,10,15,0.92)",
          borderBottom: "1px solid rgba(232,0,29,0.12)",
          backdropFilter: "blur(20px)",
          padding: "0 16px",
          display: "flex",
          alignItems: "center",
          height: "56px",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <Icon name="motorcycle" size={22} color="#E8001D" />
          <span
            style={{
              fontFamily: "Orbitron,sans-serif",
              fontWeight: 900,
              fontSize: "14px",
              letterSpacing: "2px",
            }}
          >
            CREW CHIEF
          </span>
        </div>
        <div
          style={{
            marginLeft: "auto",
            display: "flex",
            alignItems: "center",
            gap: "12px",
          }}
        >
          {settings?.riderNumber && (
            <div
              style={{
                fontFamily: "Orbitron,sans-serif",
                fontSize: "13px",
                color: "#E8001D",
                fontWeight: 700,
              }}
            >
              #{settings.riderNumber}
            </div>
          )}
          {settings?.class_ && (
            <div
              style={{
                fontSize: "10px",
                background: "rgba(232,0,29,0.15)",
                border: "1px solid rgba(232,0,29,0.3)",
                borderRadius: "4px",
                padding: "3px 8px",
                fontFamily: "Orbitron,sans-serif",
                letterSpacing: "1px",
                color: "#E8001D",
              }}
            >
              {settings.class_}
            </div>
          )}
        </div>
      </div>

      {/* Content */}
      <div
        style={{
          paddingBottom: "80px",
          minHeight: "calc(100vh - 56px)",
          overflowY: "auto",
        }}
      >
        {activeTab === "dashboard" && (
          <Dashboard
            settings={{ ...settings, riderName: rider?.name }}
            sessions={sessions}
            onAddSession={() => setShowSessionModal(true)}
          />
        )}
        {activeTab === "setup" && <SetupScreen settings={settings} />}
        {activeTab === "history" && <HistoryScreen sessions={sessions} />}
        {activeTab === "settings" && (
          <SettingsScreen
            settings={settings}
            onSave={handleSaveSettings}
            onBack={() => setActiveTab("dashboard")}
          />
        )}
      </div>

      {/* Bottom Nav */}
      <div
        style={{
          position: "fixed",
          bottom: 0,
          left: 0,
          right: 0,
          background: "rgba(10,10,15,0.95)",
          borderTop: "1px solid rgba(232,0,29,0.12)",
          backdropFilter: "blur(20px)",
          display: "flex",
          zIndex: 50,
        }}
      >
        {tabs.map((tab) => {
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                flex: 1,
                padding: "12px 4px",
                background: "none",
                border: "none",
                cursor: "pointer",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: "4px",
                transition: "all 0.2s",
                position: "relative",
              }}
            >
              {active && (
                <div
                  style={{
                    position: "absolute",
                    top: 0,
                    left: "20%",
                    right: "20%",
                    height: "2px",
                    background: "#E8001D",
                    borderRadius: "0 0 2px 2px",
                  }}
                />
              )}
              <Icon
                name={tab.icon}
                size={20}
                color={active ? "#E8001D" : "#555"}
              />
              <span
                style={{
                  fontSize: "9px",
                  fontFamily: "Orbitron,sans-serif",
                  letterSpacing: "1px",
                  color: active ? "#E8001D" : "#444",
                  textTransform: "uppercase",
                }}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>

      {showSessionModal && (
        <SessionModal
          onClose={() => setShowSessionModal(false)}
          onSave={handleSaveSession}
        />
      )}
    </div>
  );
}
