import { useState } from "react";
import CustomSelect from "../ui/CustomSelect";
import { TRACKS } from "../../data/tracks";
import { S } from "../../styles/theme";

const SessionModal = ({ onClose, onSave }) => {
  const [form, setForm] = useState({
    track: "",
    duration: 1,
    bestLap: "",
    pace: 50,
    notes: "",
    issues: [],
  });
  const toggleIssue = (i) =>
    setForm((f) => ({
      ...f,
      issues: f.issues.includes(i)
        ? f.issues.filter((x) => x !== i)
        : [...f.issues, i],
    }));
  const issues = [
    "Can't late brake",
    "Front not sticking",
    "Back stepping out",
    "Rear wobble on hard brake",
    "Understeer mid-corner",
    "Oversteer on exit",
    "Losing time in chicanes",
    "Bike not stable at top speed",
  ];

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.85)",
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "center",
        zIndex: 1000,
        backdropFilter: "blur(8px)",
      }}
    >
      <div
        style={{
          ...S.card,
          width: "100%",
          maxWidth: "600px",
          borderRadius: "20px 20px 0 0",
          padding: "28px",
          maxHeight: "85vh",
          overflowY: "auto",
        }}
      >
        <h3 style={{ ...S.heading, fontSize: "16px", marginBottom: "24px" }}>
          Log Session
        </h3>
        <div style={{ marginBottom: "16px" }}>
          <label style={S.label}>Track</label>
          <CustomSelect
            value={form.track}
            onChange={(track) => setForm((current) => ({ ...current, track }))}
            placeholder="Select circuit"
            options={TRACKS.map((track) => ({
              value: track.id,
              label: track.name,
              meta: `${track.event} · ${track.country}`,
            }))}
          />
        </div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "12px",
            marginBottom: "16px",
          }}
        >
          <div>
            <label style={S.label}>Duration (hours)</label>
            <input
              style={S.input}
              type="number"
              step="0.25"
              value={form.duration}
              onChange={(e) =>
                setForm((f) => ({
                  ...f,
                  duration: parseFloat(e.target.value) || 0,
                }))
              }
            />
          </div>
          <div>
            <label style={S.label}>Best Lap (seconds)</label>
            <input
              style={S.input}
              type="number"
              step="0.001"
              value={form.bestLap}
              onChange={(e) =>
                setForm((f) => ({ ...f, bestLap: e.target.value }))
              }
              placeholder="e.g. 92.456"
            />
          </div>
        </div>
        <div style={{ marginBottom: "16px" }}>
          <label style={S.label}>Handling Issues (select all that apply)</label>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
            {issues.map((i) => (
              <button
                key={i}
                onClick={() => toggleIssue(i)}
                style={{
                  padding: "6px 12px",
                  borderRadius: "20px",
                  fontSize: "12px",
                  cursor: "pointer",
                  border: form.issues.includes(i)
                    ? "1px solid #E8001D"
                    : "1px solid rgba(255,255,255,0.1)",
                  background: form.issues.includes(i)
                    ? "rgba(232,0,29,0.15)"
                    : "transparent",
                  color: form.issues.includes(i) ? "#E8001D" : "#888",
                  transition: "all 0.2s",
                  fontFamily: "inherit",
                }}
              >
                {i}
              </button>
            ))}
          </div>
        </div>
        <div style={{ marginBottom: "20px" }}>
          <label style={S.label}>Session Notes</label>
          <textarea
            style={{ ...S.input, minHeight: "80px", resize: "vertical" }}
            value={form.notes}
            onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
            placeholder="How did it feel? What worked, what didn't?"
          />
        </div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "12px",
          }}
        >
          <button style={S.btnGhost} onClick={onClose}>
            Cancel
          </button>
          <button
            style={S.btn}
            onClick={() => {
              onSave({ ...form, date: new Date().toISOString() });
              onClose();
            }}
          >
            Save Session
          </button>
        </div>
      </div>
    </div>
  );
};

export default SessionModal;
