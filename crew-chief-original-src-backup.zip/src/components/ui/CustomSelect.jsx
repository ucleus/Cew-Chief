import { useEffect, useRef, useState } from "react";
import Icon from "./Icon";
import { S } from "../../styles/theme";

const CustomSelect = ({
  value,
  onChange,
  options,
  placeholder = "Select an option",
  disabled = false,
}) => {
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const rootRef = useRef(null);
  const normalized = options.map((option) =>
    typeof option === "string" ? { value: option, label: option } : option,
  );
  const selected = normalized.find((option) => option.value === value);

  useEffect(() => {
    const close = (event) =>
      !rootRef.current?.contains(event.target) && setOpen(false);
    document.addEventListener("pointerdown", close);
    return () => document.removeEventListener("pointerdown", close);
  }, []);

  const choose = (option) => {
    onChange(option.value);
    setOpen(false);
  };

  const handleKeyDown = (event) => {
    if (disabled) return;
    if (["ArrowDown", "ArrowUp"].includes(event.key)) {
      event.preventDefault();
      setOpen(true);
      setActiveIndex((index) =>
        event.key === "ArrowDown"
          ? Math.min(index + 1, normalized.length - 1)
          : Math.max(index - 1, 0),
      );
    } else if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      if (open && normalized[activeIndex]) choose(normalized[activeIndex]);
      else setOpen(true);
    } else if (event.key === "Escape") setOpen(false);
  };

  return (
    <div
      ref={rootRef}
      style={{
        position: "relative",
        width: "100%",
        zIndex: open ? 300 : "auto",
      }}
    >
      <button
        type="button"
        aria-haspopup="listbox"
        aria-expanded={open}
        disabled={disabled}
        onClick={() => setOpen((state) => !state)}
        onKeyDown={handleKeyDown}
        style={{
          ...S.input,
          cursor: disabled ? "not-allowed" : "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "12px",
          textAlign: "left",
          opacity: disabled ? 0.45 : 1,
        }}
      >
        <span
          style={{
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
            color: selected ? "#E8E8F0" : "#666",
          }}
        >
          {selected?.label || placeholder}
        </span>
        <span
          style={{
            display: "flex",
            transform: open ? "rotate(-90deg)" : "rotate(90deg)",
            transition: "transform .2s",
          }}
        >
          <Icon
            name="chevronright"
            size={16}
            color={open ? "#E8001D" : "#666"}
          />
        </span>
      </button>
      {open && (
        <div
          role="listbox"
          style={{
            position: "absolute",
            zIndex: 300,
            top: "calc(100% + 6px)",
            left: 0,
            right: 0,
            maxHeight: "260px",
            overflowY: "auto",
            padding: "6px",
            background: "rgba(15,15,22,.98)",
            border: "1px solid rgba(232,0,29,.35)",
            borderRadius: "10px",
            boxShadow: "0 18px 50px rgba(0,0,0,.55)",
            backdropFilter: "blur(20px)",
          }}
        >
          {normalized.map((option, index) => (
            <button
              type="button"
              role="option"
              aria-selected={option.value === value}
              key={option.value}
              onMouseEnter={() => setActiveIndex(index)}
              onClick={() => choose(option)}
              style={{
                width: "100%",
                border: 0,
                borderRadius: "7px",
                padding: "11px 12px",
                textAlign: "left",
                cursor: "pointer",
                fontFamily: "inherit",
                fontSize: "13px",
                color: option.value === value ? "#fff" : "#aaa",
                background:
                  option.value === value
                    ? "linear-gradient(90deg,rgba(232,0,29,.28),rgba(232,0,29,.08))"
                    : index === activeIndex
                      ? "rgba(255,255,255,.06)"
                      : "transparent",
              }}
            >
              {option.label}
              {option.meta && (
                <span
                  style={{
                    display: "block",
                    color: "#666",
                    fontSize: "10px",
                    marginTop: "3px",
                  }}
                >
                  {option.meta}
                </span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default CustomSelect;
