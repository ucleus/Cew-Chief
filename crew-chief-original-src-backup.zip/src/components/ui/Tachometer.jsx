const Tachometer = ({
  value = 0,
  max = 100,
  label = "",
  color = "#E8001D",
}) => {
  const pct = Math.min(value / max, 1);
  const angle = -135 + pct * 270;
  const r = 44;
  const cx = 60,
    cy = 60;
  const startAngle = -135 * (Math.PI / 180);
  const endAngle = startAngle + (pct * 270 * Math.PI) / 180;
  const x1 = cx + r * Math.cos(startAngle);
  const y1 = cy + r * Math.sin(startAngle);
  const x2 = cx + r * Math.cos(endAngle);
  const y2 = cy + r * Math.sin(endAngle);
  const largeArc = pct * 270 > 180 ? 1 : 0;

  return (
    <div style={{ textAlign: "center" }}>
      <svg width="120" height="100" viewBox="0 0 120 100">
        <circle
          cx={cx}
          cy={cy}
          r={r}
          fill="none"
          stroke="rgba(255,255,255,0.06)"
          strokeWidth="8"
          strokeDasharray="3 2"
        />
        {pct > 0 && (
          <path
            d={`M ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2}`}
            fill="none"
            stroke={color}
            strokeWidth="6"
            strokeLinecap="round"
          />
        )}
        <line
          x1={cx}
          y1={cy}
          x2={cx + (r - 10) * Math.cos((angle * Math.PI) / 180)}
          y2={cy + (r - 10) * Math.sin((angle * Math.PI) / 180)}
          stroke={color}
          strokeWidth="2.5"
          strokeLinecap="round"
        />
        <circle cx={cx} cy={cy} r="4" fill={color} />
        <text
          x={cx}
          y={cy + 22}
          textAnchor="middle"
          fill="#E8E8F0"
          fontSize="14"
          fontFamily="Orbitron,sans-serif"
          fontWeight="900"
        >
          {Math.round(value)}
        </text>
      </svg>
      <div
        style={{
          fontSize: "10px",
          letterSpacing: "2px",
          textTransform: "uppercase",
          color: "#888",
          fontFamily: "Orbitron,sans-serif",
        }}
      >
        {label}
      </div>
    </div>
  );
};

export default Tachometer;
