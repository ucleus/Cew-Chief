import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import Icon from "../components/ui/Icon";
import Tachometer from "../components/ui/Tachometer";
import { S } from "../styles/theme";

const Dashboard = ({ settings, sessions, onAddSession }) => {
  const totalHours = sessions.reduce((a, s) => a + (s.duration || 0), 0);
  const totalSessions = sessions.length;
  const avgLapDelta =
    sessions.length > 1
      ? (
          (sessions[sessions.length - 1].bestLap || 0) -
          (sessions[0].bestLap || 0)
        ).toFixed(3)
      : null;
  const standing = settings?.standing || "P--";

  const sparkData = sessions.slice(-10).map((s, i) => ({
    session: i + 1,
    lap: s.bestLap || 0,
    pace: s.pace || 50,
  }));

  return (
    <div style={{ padding: "16px" }}>
      {/* Rider Card */}
      <div
        style={{
          background:
            "linear-gradient(135deg, rgba(232,0,29,0.15), rgba(26,26,36,0.95))",
          border: "1px solid rgba(232,0,29,0.3)",
          borderRadius: "16px",
          padding: "24px",
          marginBottom: "16px",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            top: "-20px",
            right: "-20px",
            fontSize: "120px",
            fontFamily: "Orbitron,sans-serif",
            fontWeight: 900,
            color: "rgba(232,0,29,0.06)",
            lineHeight: 1,
          }}
        >
          {settings?.riderNumber || "#0"}
        </div>
        <div style={{ display: "flex", alignItems: "flex-start", gap: "16px" }}>
          <div
            style={{
              width: "56px",
              height: "56px",
              borderRadius: "50%",
              background: "linear-gradient(135deg,#E8001D,#FF4D00)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <Icon name="user" size={24} color="#fff" />
          </div>
          <div style={{ flex: 1 }}>
            <div
              style={{
                fontSize: "11px",
                letterSpacing: "3px",
                color: "#E8001D",
                fontFamily: "Orbitron,sans-serif",
                marginBottom: "4px",
              }}
            >
              {settings?.class_ || "MotoGP"} RIDER
            </div>
            <h2
              style={{
                ...S.heading,
                fontSize: "clamp(18px,4vw,24px)",
                marginBottom: "4px",
              }}
            >
              {settings?.riderName || "Rider"}
            </h2>
            <div style={{ fontSize: "13px", color: "#888" }}>
              {settings?.team || "No Team Set"} ·{" "}
              {settings?.manufacturer || "—"}
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ ...S.heading, fontSize: "32px", color: "#E8001D" }}>
              {settings?.standing || "P—"}
            </div>
            <div
              style={{
                fontSize: "10px",
                letterSpacing: "2px",
                color: "#666",
                fontFamily: "Orbitron,sans-serif",
              }}
            >
              STANDING
            </div>
          </div>
        </div>
      </div>

      {/* Stats Row */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3,1fr)",
          gap: "10px",
          marginBottom: "16px",
        }}
      >
        {[
          {
            label: "Total Hours",
            value: totalHours.toFixed(1) + "h",
            color: "#00D4FF",
            icon: "clock",
          },
          {
            label: "Sessions",
            value: totalSessions,
            color: "#E8001D",
            icon: "flag",
          },
          {
            label: "Lap Delta",
            value: avgLapDelta
              ? (avgLapDelta > 0 ? "+" : "") + avgLapDelta + "s"
              : "—",
            color: avgLapDelta < 0 ? "#00FF88" : "#FF4D00",
            icon: "chart",
          },
        ].map((stat) => (
          <div
            key={stat.label}
            style={{ ...S.card, textAlign: "center", padding: "16px 8px" }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginBottom: "8px",
              }}
            >
              <Icon name={stat.icon} size={18} color={stat.color} />
            </div>
            <div
              style={{
                ...S.heading,
                fontSize: "clamp(16px,4vw,22px)",
                color: stat.color,
              }}
            >
              {stat.value}
            </div>
            <div
              style={{
                fontSize: "10px",
                color: "#666",
                fontFamily: "Orbitron,sans-serif",
                letterSpacing: "1px",
                marginTop: "4px",
              }}
            >
              {stat.label}
            </div>
          </div>
        ))}
      </div>

      {/* Tachometers */}
      <div style={{ ...S.card, marginBottom: "16px" }}>
        <div
          style={{
            fontSize: "11px",
            letterSpacing: "2px",
            color: "#888",
            fontFamily: "Orbitron,sans-serif",
            marginBottom: "16px",
          }}
        >
          PERFORMANCE GAUGES
        </div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3,1fr)",
            gap: "8px",
          }}
        >
          <Tachometer
            value={settings?.consistency || 72}
            max={100}
            label="Consistency"
            color="#00D4FF"
          />
          <Tachometer
            value={settings?.aggression || 85}
            max={100}
            label="Aggression"
            color="#E8001D"
          />
          <Tachometer
            value={settings?.setup || 60}
            max={100}
            label="Setup Score"
            color="#FF6B00"
          />
        </div>
      </div>

      {/* Pace Chart */}
      {sparkData.length > 1 && (
        <div style={{ ...S.card, marginBottom: "16px" }}>
          <div
            style={{
              fontSize: "11px",
              letterSpacing: "2px",
              color: "#888",
              fontFamily: "Orbitron,sans-serif",
              marginBottom: "16px",
            }}
          >
            PACE TREND — LAST 10 SESSIONS
          </div>
          <ResponsiveContainer width="100%" height={140}>
            <LineChart data={sparkData}>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="rgba(255,255,255,0.05)"
              />
              <XAxis dataKey="session" tick={{ fill: "#666", fontSize: 10 }} />
              <YAxis tick={{ fill: "#666", fontSize: 10 }} />
              <Tooltip
                contentStyle={{
                  background: "#1A1A24",
                  border: "1px solid #E8001D",
                  borderRadius: "8px",
                  color: "#E8E8F0",
                }}
              />
              <Line
                type="monotone"
                dataKey="pace"
                stroke="#00D4FF"
                strokeWidth={2}
                dot={{ fill: "#00D4FF", r: 3 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Daily Goal */}
      <div style={{ ...S.cardCyan, marginBottom: "16px" }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: "12px",
          }}
        >
          <div
            style={{
              fontSize: "11px",
              letterSpacing: "2px",
              color: "#00D4FF",
              fontFamily: "Orbitron,sans-serif",
            }}
          >
            DAILY SESSION GOAL
          </div>
          <div style={{ ...S.mono, fontSize: "12px", color: "#00D4FF" }}>
            {Math.min((totalHours % 1) * 60, 60).toFixed(0)}m / 60m
          </div>
        </div>
        <div
          style={{
            height: "6px",
            background: "rgba(255,255,255,0.05)",
            borderRadius: "3px",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              height: "100%",
              width: `${Math.min((totalHours % 1) * 100, 100)}%`,
              background: "linear-gradient(90deg,#00D4FF,#0090CC)",
              borderRadius: "3px",
              transition: "width 0.5s ease",
            }}
          />
        </div>
        <p
          style={{
            fontSize: "12px",
            color: "#888",
            marginTop: "10px",
            lineHeight: 1.5,
          }}
        >
          1 hour daily keeps your muscle memory sharp. Consistency beats
          marathon sessions. Log your session after each run.
        </p>
      </div>

      <button style={{ ...S.btn, width: "100%" }} onClick={onAddSession}>
        <span
          style={{
            display: "flex",
            alignItems: "center",
            gap: "8px",
            justifyContent: "center",
          }}
        >
          <Icon name="plus" size={16} color="#fff" /> Log Session
        </span>
      </button>
    </div>
  );
};

export default Dashboard;
