import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import Icon from "../components/ui/Icon";
import { TRACKS } from "../data/tracks";
import { S } from "../styles/theme";

const HistoryScreen = ({ sessions }) => {
  const data = sessions.map((s, i) => ({
    name: `S${i + 1}`,
    lap: parseFloat(s.bestLap) || 0,
    duration: s.duration || 0,
  }));

  return (
    <div style={{ padding: "16px" }}>
      <h2 style={{ ...S.heading, fontSize: "18px", marginBottom: "20px" }}>
        Progress Archive
      </h2>

      {sessions.length === 0 ? (
        <div
          style={{ textAlign: "center", padding: "60px 20px", color: "#555" }}
        >
          <Icon name="chart" size={40} color="#333" />
          <p
            style={{
              marginTop: "16px",
              fontFamily: "Orbitron,sans-serif",
              fontSize: "12px",
              letterSpacing: "2px",
            }}
          >
            NO SESSIONS LOGGED
          </p>
          <p style={{ fontSize: "13px" }}>
            Start racing and log your sessions to track progress.
          </p>
        </div>
      ) : (
        <>
          {data.some((d) => d.lap > 0) && (
            <div style={{ ...S.card, marginBottom: "16px" }}>
              <div
                style={{
                  fontSize: "11px",
                  letterSpacing: "2px",
                  color: "#00D4FF",
                  fontFamily: "Orbitron,sans-serif",
                  marginBottom: "16px",
                }}
              >
                BEST LAP PROGRESSION
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={data}>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="rgba(255,255,255,0.05)"
                  />
                  <XAxis dataKey="name" tick={{ fill: "#666", fontSize: 11 }} />
                  <YAxis tick={{ fill: "#666", fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{
                      background: "#1A1A24",
                      border: "1px solid #00D4FF",
                      borderRadius: "8px",
                      color: "#E8E8F0",
                    }}
                    formatter={(v) => [v.toFixed(3) + "s", "Best Lap"]}
                  />
                  <Line
                    type="monotone"
                    dataKey="lap"
                    stroke="#00D4FF"
                    strokeWidth={2}
                    dot={{ fill: "#00D4FF", r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          <div
            style={{ display: "flex", flexDirection: "column", gap: "10px" }}
          >
            {[...sessions].reverse().map((s, i) => {
              const track = TRACKS.find((t) => t.id === s.track);
              return (
                <div key={i} style={{ ...S.card, padding: "16px" }}>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "flex-start",
                      marginBottom: "8px",
                    }}
                  >
                    <div>
                      <div style={{ fontWeight: 600, fontSize: "14px" }}>
                        {track?.name || s.track || "Unknown Track"}
                      </div>
                      <div
                        style={{
                          fontSize: "11px",
                          color: "#666",
                          marginTop: "2px",
                        }}
                      >
                        {new Date(s.date).toLocaleDateString()}
                      </div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      {s.bestLap && (
                        <div
                          style={{
                            ...S.mono,
                            fontSize: "16px",
                            color: "#00D4FF",
                          }}
                        >
                          {parseFloat(s.bestLap).toFixed(3)}s
                        </div>
                      )}
                      <div style={{ fontSize: "11px", color: "#666" }}>
                        {s.duration}h session
                      </div>
                    </div>
                  </div>
                  {s.issues?.length > 0 && (
                    <div
                      style={{
                        display: "flex",
                        flexWrap: "wrap",
                        gap: "4px",
                        marginTop: "8px",
                      }}
                    >
                      {s.issues.map((issue) => (
                        <span
                          key={issue}
                          style={{
                            fontSize: "10px",
                            padding: "3px 8px",
                            background: "rgba(255,107,0,0.12)",
                            border: "1px solid rgba(255,107,0,0.25)",
                            borderRadius: "12px",
                            color: "#FF6B00",
                          }}
                        >
                          {issue}
                        </span>
                      ))}
                    </div>
                  )}
                  {s.notes && (
                    <p
                      style={{
                        fontSize: "12px",
                        color: "#888",
                        marginTop: "8px",
                        marginBottom: 0,
                        lineHeight: 1.5,
                      }}
                    >
                      {s.notes}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
};

export default HistoryScreen;
