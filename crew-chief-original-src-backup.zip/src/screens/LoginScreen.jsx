import { useEffect, useState } from "react";
import Icon from "../components/ui/Icon";
import { S } from "../styles/theme";

const LoginScreen = ({ onLogin }) => {
  const [pin, setPin] = useState("");
  const [name, setName] = useState("");
  const [isNew, setIsNew] = useState(false);
  const [error, setError] = useState("");
  const [glitch, setGlitch] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("mgp_rider");
    if (!stored) setIsNew(true);
  }, []);

  const handleLogin = () => {
    if (!name.trim()) {
      setError("Enter your rider name.");
      return;
    }
    if (pin.length < 4) {
      setError("PIN must be at least 4 digits.");
      return;
    }
    const stored = localStorage.getItem("mgp_rider");
    if (stored) {
      const data = JSON.parse(stored);
      if (data.pin !== pin) {
        setGlitch(true);
        setError("Invalid PIN. Try again.");
        setTimeout(() => setGlitch(false), 600);
        return;
      }
      onLogin(data);
    } else {
      const rider = { name: name.trim(), pin, createdAt: Date.now() };
      localStorage.setItem("mgp_rider", JSON.stringify(rider));
      onLogin(rider);
    }
  };

  return (
    <div
      style={{
        ...S.app,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "20px",
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;600&display=swap');
        * { box-sizing: border-box; }
        body { margin: 0; background: #0A0A0F; }
        @keyframes scanline { 0% { transform: translateY(-100%) } 100% { transform: translateY(100vh) } }
        @keyframes pulse-red { 0%,100% { opacity:1 } 50% { opacity:0.4 } }
        @keyframes glitch { 0%,100%{transform:translateX(0)} 20%{transform:translateX(-4px)} 40%{transform:translateX(4px)} 60%{transform:translateX(-2px)} 80%{transform:translateX(2px)} }
        .login-glitch { animation: glitch 0.3s ease; }
        input:focus { border-color: #E8001D !important; box-shadow: 0 0 0 2px rgba(232,0,29,0.15); }
      `}</style>

      {/* Background grid */}
      <div
        style={{
          position: "fixed",
          inset: 0,
          backgroundImage:
            "linear-gradient(rgba(232,0,29,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(232,0,29,0.03) 1px,transparent 1px)",
          backgroundSize: "40px 40px",
          pointerEvents: "none",
        }}
      />
      <div
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          height: "2px",
          background: "linear-gradient(90deg,transparent,#E8001D,transparent)",
          animation: "scanline 4s linear infinite",
          opacity: 0.4,
          pointerEvents: "none",
        }}
      />

      <div style={{ width: "100%", maxWidth: "420px" }}>
        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: "40px" }}>
          <div
            style={{
              display: "inline-block",
              padding: "12px 20px",
              background: "rgba(232,0,29,0.1)",
              border: "1px solid rgba(232,0,29,0.3)",
              borderRadius: "4px",
              marginBottom: "16px",
            }}
          >
            <Icon name="motorcycle" size={36} color="#E8001D" />
          </div>
          <h1
            style={{
              ...S.heading,
              fontSize: "clamp(22px,5vw,28px)",
              color: "#fff",
              marginBottom: "4px",
            }}
          >
            CREW CHIEF
          </h1>
          <div
            style={{
              fontSize: "10px",
              letterSpacing: "4px",
              color: "#E8001D",
              fontFamily: "Orbitron,sans-serif",
            }}
          >
            MOTOGP26 RACE ENGINEER
          </div>
        </div>

        <div
          className={glitch ? "login-glitch" : ""}
          style={{ ...S.card, padding: "32px" }}
        >
          <div style={{ marginBottom: "20px" }}>
            <label style={S.label}>Rider Name</label>
            <input
              style={S.input}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
            />
          </div>
          <div style={{ marginBottom: "28px" }}>
            <label style={S.label}>PIN Code</label>
            <input
              style={S.input}
              type="password"
              value={pin}
              onChange={(e) =>
                setPin(e.target.value.replace(/\D/g, "").slice(0, 6))
              }
              placeholder={isNew ? "Create a 4-6 digit PIN" : "Enter your PIN"}
              onKeyDown={(e) => e.key === "Enter" && handleLogin()}
            />
          </div>
          {error && (
            <div
              style={{
                color: "#FF4D00",
                fontSize: "12px",
                marginBottom: "16px",
                fontFamily: "JetBrains Mono,monospace",
              }}
            >
              {error}
            </div>
          )}
          <button
            style={{
              ...S.btn,
              width: "100%",
              fontSize: "14px",
              padding: "16px",
            }}
            onClick={handleLogin}
          >
            {isNew ? "Create Account" : "Enter Garage"}
          </button>
          {!isNew && (
            <button
              style={{
                width: "100%",
                background: "transparent",
                border: "none",
                color: "#555",
                cursor: "pointer",
                marginTop: "12px",
                fontSize: "12px",
                fontFamily: "inherit",
              }}
              onClick={() => {
                localStorage.removeItem("mgp_rider");
                setIsNew(true);
                setError("");
              }}
            >
              New rider? Start fresh
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;
