import { useState } from "react";
import CustomSelect from "../components/ui/CustomSelect";
import Icon from "../components/ui/Icon";
import { CLASS_BIKES, CLASS_TEAMS, RACING_CLASSES } from "../data/championship";
import { S } from "../styles/theme";

const SettingsScreen = ({ settings, onSave, onBack }) => {
  const [form, setForm] = useState(
    settings || {
      apiKey: "",
      riderNumber: "",
      team: "",
      teamNationality: "",
      class_: "MotoGP",
      manufacturer: "Ducati",
      sponsor: "",
      manager: "",
      engineeringStaff: "",
    },
  );
  const [showKey, setShowKey] = useState(false);
  const [saved, setSaved] = useState(false);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const changeClass = (className) =>
    setForm((current) => ({
      ...current,
      class_: className,
      team: "",
      manufacturer: "",
    }));

  const handleSave = () => {
    localStorage.setItem("mgp_settings", JSON.stringify(form));
    onSave(form);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div style={{ padding: "20px", maxWidth: "700px", margin: "0 auto" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;600&display=swap'); *{box-sizing:border-box} input:focus,select:focus,textarea:focus{border-color:#E8001D!important;outline:none;box-shadow:0 0 0 2px rgba(232,0,29,0.15)}`}</style>

      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "12px",
          marginBottom: "28px",
        }}
      >
        <button
          style={{
            background: "none",
            border: "none",
            color: "#888",
            cursor: "pointer",
            padding: "8px",
          }}
          onClick={onBack}
        >
          <Icon name="chevronright" size={20} color="#888" />
        </button>
        <h2 style={{ ...S.heading, fontSize: "18px", margin: 0 }}>
          Garage Settings
        </h2>
      </div>

      {/* AI API Key */}
      <div style={{ ...S.card, marginBottom: "16px" }}>
        <h3
          style={{
            ...S.heading,
            fontSize: "13px",
            color: "#E8001D",
            marginBottom: "20px",
          }}
        >
          AI Engine
        </h3>
        <label style={S.label}>Anthropic API Key</label>
        <div style={{ position: "relative" }}>
          <input
            style={{
              ...S.input,
              paddingRight: "48px",
              fontFamily: "JetBrains Mono,monospace",
              fontSize: "13px",
            }}
            type={showKey ? "text" : "password"}
            value={form.apiKey}
            onChange={(e) => set("apiKey", e.target.value)}
            placeholder="sk-ant-..."
          />
          <button
            onClick={() => setShowKey(!showKey)}
            style={{
              position: "absolute",
              right: "12px",
              top: "50%",
              transform: "translateY(-50%)",
              background: "none",
              border: "none",
              cursor: "pointer",
              color: "#555",
              padding: "4px",
            }}
          >
            <Icon name={showKey ? "eyeoff" : "eye"} size={16} color="#555" />
          </button>
        </div>
        <p style={{ fontSize: "11px", color: "#555", marginTop: "8px" }}>
          Your key is stored locally only. Never transmitted except directly to
          Anthropic.
        </p>
      </div>

      {/* Rider Profile */}
      <div style={{ ...S.card, marginBottom: "16px" }}>
        <h3
          style={{
            ...S.heading,
            fontSize: "13px",
            color: "#00D4FF",
            marginBottom: "20px",
          }}
        >
          Rider Profile
        </h3>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "16px",
          }}
        >
          <div>
            <label style={S.label}>Racing Number</label>
            <input
              style={S.input}
              value={form.riderNumber}
              onChange={(e) => set("riderNumber", e.target.value)}
              placeholder="#46"
            />
          </div>
          <div>
            <label style={S.label}>Class</label>
            <CustomSelect
              value={form.class_}
              onChange={changeClass}
              options={RACING_CLASSES}
              placeholder="Select class"
            />
          </div>
        </div>
        <div style={{ marginTop: "16px" }}>
          <label style={S.label}>Team Name</label>
          <CustomSelect
            value={form.team}
            onChange={(value) => set("team", value)}
            options={CLASS_TEAMS[form.class_] || []}
            placeholder={`Select ${form.class_} team`}
          />
        </div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "16px",
            marginTop: "16px",
          }}
        >
          <div>
            <label style={S.label}>Bike</label>
            <CustomSelect
              value={form.manufacturer}
              onChange={(value) => set("manufacturer", value)}
              options={CLASS_BIKES[form.class_] || []}
              placeholder={`Select ${form.class_} bike`}
            />
          </div>
          <div>
            <label style={S.label}>Team Nationality</label>
            <input
              style={S.input}
              value={form.teamNationality}
              onChange={(e) => set("teamNationality", e.target.value)}
              placeholder="Italian, Spanish..."
            />
          </div>
        </div>
        <div style={{ marginTop: "16px" }}>
          <label style={S.label}>Sponsor</label>
          <input
            style={S.input}
            value={form.sponsor}
            onChange={(e) => set("sponsor", e.target.value)}
            placeholder="Primary sponsor name"
          />
        </div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "16px",
            marginTop: "16px",
          }}
        >
          <div>
            <label style={S.label}>Team Manager</label>
            <input
              style={S.input}
              value={form.manager}
              onChange={(e) => set("manager", e.target.value)}
              placeholder="Manager name"
            />
          </div>
          <div>
            <label style={S.label}>Engineering Staff</label>
            <input
              style={S.input}
              value={form.engineeringStaff}
              onChange={(e) => set("engineeringStaff", e.target.value)}
              placeholder="Head engineer"
            />
          </div>
        </div>
      </div>

      <button
        style={{ ...S.btn, width: "100%", padding: "16px" }}
        onClick={handleSave}
      >
        {saved ? (
          <span
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              justifyContent: "center",
            }}
          >
            <Icon name="checkmark" size={16} color="#fff" /> Saved
          </span>
        ) : (
          "Save Settings"
        )}
      </button>
    </div>
  );
};

export default SettingsScreen;
