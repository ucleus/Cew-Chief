import { useState } from "react";
import CustomSelect from "../components/ui/CustomSelect";
import Icon from "../components/ui/Icon";
import { TRACKS } from "../data/tracks";
import { S } from "../styles/theme";

const SetupScreen = ({ settings }) => {
  const [selectedTrack, setSelectedTrack] = useState(null);
  const [issues, setIssues] = useState([]);
  const [customProblem, setCustomProblem] = useState("");
  const [setup, setSetup] = useState(null);
  const [loading, setLoading] = useState(false);
  const [savedSetups, setSavedSetups] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("mgp_setups") || "{}");
    } catch {
      return {};
    }
  });
  const toggleIssue = (i) =>
    setIssues((f) => (f.includes(i) ? f.filter((x) => x !== i) : [...f, i]));

  const handleendGenerate = async () => {
    if (!selectedTrack || !settings?.apiKey) return;
    setLoading(true);
    setSetup(null);
    const track = TRACKS.find((t) => t.id === selectedTrack);
    const class_ = settings?.class_ || "MotoGP";
    const manufacturer = settings?.manufacturer || "Ducati";

    const systemPrompt = `You are the head race engineer and crew chief for a MotoGP team — world class, no-nonsense, technical. You speak directly, like a seasoned Italian race engineer who has won multiple world championships. You do NOT coddle the rider. You give exact numbers, explain the physics, and tell them exactly what will happen if they don't follow the setup. You are NOT their friend. You are there to make them faster.

Always respond in this EXACT JSON format (no markdown, no extra text):
{
  "headline": "One brutal honest assessment sentence",
  "suspension_front": {"compression": <1-20>, "rebound": <1-20>, "preload": <1-10>, "height": <1-10>, "notes": "detailed explanation with physics"},
  "suspension_rear": {"compression": <1-20>, "rebound": <1-20>, "preload": <1-10>, "height": <1-10>, "notes": "detailed explanation with physics"},
  "braking": {"bias": <45-60>, "engine_brake": <1-8>, "notes": "detailed explanation"},
  "gearing": {"primary": <value>, "first": <value>, "top": <value>, "notes": "detailed gear strategy with sector breakdown"},
  "aero": {"front_downforce": <1-10>, "rear_downforce": <1-10>, "ride_height_device": true|false, "notes": "explanation"},
  "electronics": {"tc_setting_1": <1-12>, "tc_setting_2": <1-12>, "wheelie_control": <1-8>, "engine_map": <1-6>, "anti_wheelie": <1-6>, "engine_brake_strategy": "explanation"},
  "issue_fixes": [{"issue": "problem name", "fix": "exact what to change and why with physics explanation", "priority": "CRITICAL|HIGH|MEDIUM"}],
  "coach_notes": "A brutally honest, technically deep paragraph — what the rider MUST do in this session, common mistakes at this track, mental cues, braking markers. Do not be nice. Be a world championship engineer.",
  "lap_time_potential": "estimated improvement if setup followed correctly"
}`;

    const userMsg = `Track: ${track.name}, ${track.country}
Type: ${track.type}
Length: ${track.length}, Corners: ${track.corners}
Class: ${class_}
Manufacturer: ${manufacturer}
Reported problems: ${issues.length > 0 ? issues.join(", ") : "None reported"}
Additional notes: ${customProblem || "None"}

Generate a complete, deep, championship-level race setup. Every number must be justified with physics.`;

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": settings.apiKey,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true",
        },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 2000,
          system: systemPrompt,
          messages: [{ role: "user", content: userMsg }],
        }),
      });
      const data = await res.json();
      const text = data.content?.[0]?.text || "";
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setSetup(parsed);
    } catch (e) {
      setSetup({
        headline: "API Error — Check your key in Settings.",
        coach_notes: e.message,
      });
    }
    setLoading(false);
  };

  const saveSetup = () => {
    if (!setup || !selectedTrack) return;
    const key = `${selectedTrack}_${settings?.class_}_${Date.now()}`;
    const updated = {
      ...savedSetups,
      [key]: {
        ...setup,
        track: selectedTrack,
        class_: settings?.class_,
        date: new Date().toISOString(),
      },
    };
    setSavedSetups(updated);
    localStorage.setItem("mgp_setups", JSON.stringify(updated));
  };

  const issueOptions = [
    "Can't late brake",
    "Front not sticking to line",
    "Rear wobble on hard brake",
    "Understeer mid-corner",
    "Oversteer on exit",
    "Wheelspin on acceleration",
    "Chattering front tyre",
    "Rear slides on decel",
    "Losing time on straights",
    "Instability at top speed",
  ];

  return (
    <div style={{ padding: "16px" }}>
      {/* Track Select */}
      <div
        style={{
          ...S.card,
          marginBottom: "16px",
          position: "relative",
          zIndex: 20,
        }}
      >
        <h3
          style={{
            ...S.heading,
            fontSize: "13px",
            color: "#E8001D",
            marginBottom: "16px",
          }}
        >
          <span style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <Icon name="map" size={14} color="#E8001D" /> Select Circuit
          </span>
        </h3>
        <CustomSelect
          value={selectedTrack || ""}
          onChange={(track) => {
            setSelectedTrack(track);
            setSetup(null);
          }}
          placeholder="Choose your battleground..."
          options={TRACKS.map((track) => ({
            value: track.id,
            label: track.name,
            meta: `${track.event} · ${track.type}`,
          }))}
        />
        {selectedTrack &&
          (() => {
            const t = TRACKS.find((x) => x.id === selectedTrack);
            return (
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(3,1fr)",
                  gap: "8px",
                  marginTop: "12px",
                }}
              >
                {[
                  ["Length", t.length],
                  ["Corners", t.corners],
                  ["Type", t.type],
                ].map(([k, v]) => (
                  <div
                    key={k}
                    style={{
                      background: "rgba(255,255,255,0.03)",
                      borderRadius: "6px",
                      padding: "10px",
                      textAlign: "center",
                    }}
                  >
                    <div
                      style={{
                        fontSize: "10px",
                        color: "#666",
                        fontFamily: "Orbitron,sans-serif",
                        letterSpacing: "1px",
                      }}
                    >
                      {k}
                    </div>
                    <div
                      style={{
                        fontSize: "12px",
                        color: "#E8E8F0",
                        marginTop: "4px",
                        fontFamily: "JetBrains Mono,monospace",
                      }}
                    >
                      {v}
                    </div>
                  </div>
                ))}
              </div>
            );
          })()}
      </div>

      {/* Issues */}
      <div style={{ ...S.card, marginBottom: "16px" }}>
        <h3
          style={{
            ...S.heading,
            fontSize: "13px",
            color: "#FF6B00",
            marginBottom: "16px",
          }}
        >
          <span style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <Icon name="alert" size={14} color="#FF6B00" /> Handling Problems
          </span>
        </h3>
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: "8px",
            marginBottom: "12px",
          }}
        >
          {issueOptions.map((i) => (
            <button
              key={i}
              onClick={() => toggleIssue(i)}
              style={{
                padding: "7px 12px",
                borderRadius: "20px",
                fontSize: "11px",
                cursor: "pointer",
                border: issues.includes(i)
                  ? "1px solid #FF6B00"
                  : "1px solid rgba(255,255,255,0.1)",
                background: issues.includes(i)
                  ? "rgba(255,107,0,0.15)"
                  : "transparent",
                color: issues.includes(i) ? "#FF6B00" : "#888",
                transition: "all 0.2s",
                fontFamily: "inherit",
              }}
            >
              {i}
            </button>
          ))}
        </div>
        <textarea
          style={{
            ...S.input,
            minHeight: "70px",
            resize: "vertical",
            fontSize: "13px",
          }}
          value={customProblem}
          onChange={(e) => setCustomProblem(e.target.value)}
          placeholder="Describe anything else — e.g. 'I can't hold my line through Turn 9, the rear just steps out under throttle every time...'"
        />
      </div>

      <button
        style={{
          ...S.btn,
          width: "100%",
          padding: "16px",
          marginBottom: "24px",
          opacity: !selectedTrack || !settings?.apiKey ? 0.5 : 1,
        }}
        onClick={handleendGenerate}
        disabled={loading || !selectedTrack || !settings?.apiKey}
      >
        {loading ? (
          <span
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              justifyContent: "center",
            }}
          >
            <Icon name="refresh" size={16} color="#fff" /> Engineer is
            calculating...
          </span>
        ) : (
          <span
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              justifyContent: "center",
            }}
          >
            <Icon name="zap" size={16} color="#fff" /> Generate Championship
            Setup
          </span>
        )}
      </button>

      {!settings?.apiKey && (
        <p
          style={{
            textAlign: "center",
            color: "#555",
            fontSize: "12px",
            marginTop: "-16px",
            marginBottom: "16px",
          }}
        >
          Add your Anthropic API key in Settings first.
        </p>
      )}

      {/* Setup Output */}
      {setup && (
        <div style={{ animation: "fadeIn 0.4s ease" }}>
          <style>
            {
              "@keyframes fadeIn{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}"
            }
          </style>

          {/* Headline */}
          <div
            style={{
              background:
                "linear-gradient(135deg,rgba(232,0,29,0.2),rgba(26,26,36,0.9))",
              border: "1px solid rgba(232,0,29,0.4)",
              borderRadius: "12px",
              padding: "20px",
              marginBottom: "16px",
            }}
          >
            <div
              style={{
                fontSize: "11px",
                letterSpacing: "2px",
                color: "#E8001D",
                fontFamily: "Orbitron,sans-serif",
                marginBottom: "8px",
              }}
            >
              ENGINEER ASSESSMENT
            </div>
            <p
              style={{
                margin: 0,
                fontSize: "15px",
                fontWeight: 600,
                lineHeight: 1.5,
                color: "#E8E8F0",
              }}
            >
              {setup.headline}
            </p>
          </div>

          {/* Setup Cards */}
          {[
            {
              key: "suspension_front",
              label: "Front Suspension",
              color: "#00D4FF",
              fields: ["compression", "rebound", "preload", "height"],
            },
            {
              key: "suspension_rear",
              label: "Rear Suspension",
              color: "#00D4FF",
              fields: ["compression", "rebound", "preload", "height"],
            },
            {
              key: "braking",
              label: "Braking System",
              color: "#E8001D",
              fields: ["bias", "engine_brake"],
            },
            {
              key: "aero",
              label: "Aerodynamics",
              color: "#FF6B00",
              fields: ["front_downforce", "rear_downforce"],
            },
          ]
            .filter((s) => setup[s.key])
            .map((section) => (
              <div
                key={section.key}
                style={{ ...S.card, marginBottom: "12px" }}
              >
                <div
                  style={{
                    fontSize: "11px",
                    letterSpacing: "2px",
                    color: section.color,
                    fontFamily: "Orbitron,sans-serif",
                    marginBottom: "14px",
                  }}
                >
                  {section.label}
                </div>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: `repeat(${Math.min(section.fields.length, 4)}, 1fr)`,
                    gap: "8px",
                    marginBottom: "12px",
                  }}
                >
                  {section.fields.map((f) => (
                    <div
                      key={f}
                      style={{
                        background: "rgba(255,255,255,0.03)",
                        borderRadius: "8px",
                        padding: "12px",
                        textAlign: "center",
                      }}
                    >
                      <div
                        style={{
                          ...S.heading,
                          fontSize: "22px",
                          color: section.color,
                        }}
                      >
                        {setup[section.key][f]}
                        {f === "bias" ? "%" : ""}
                        {typeof setup[section.key][f] === "boolean"
                          ? setup[section.key][f]
                            ? "ON"
                            : "OFF"
                          : ""}
                      </div>
                      <div
                        style={{
                          fontSize: "9px",
                          color: "#666",
                          fontFamily: "Orbitron,sans-serif",
                          letterSpacing: "1px",
                          marginTop: "4px",
                          textTransform: "uppercase",
                        }}
                      >
                        {f.replace(/_/g, " ")}
                      </div>
                    </div>
                  ))}
                </div>
                <p
                  style={{
                    ...S.mono,
                    fontSize: "12px",
                    color: "#AAA",
                    lineHeight: 1.7,
                    margin: 0,
                  }}
                >
                  {setup[section.key].notes}
                </p>
              </div>
            ))}

          {/* Electronics */}
          {setup.electronics && (
            <div style={{ ...S.card, marginBottom: "12px" }}>
              <div
                style={{
                  fontSize: "11px",
                  letterSpacing: "2px",
                  color: "#B026FF",
                  fontFamily: "Orbitron,sans-serif",
                  marginBottom: "14px",
                }}
              >
                ELECTRONICS
              </div>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(3, 1fr)",
                  gap: "8px",
                  marginBottom: "12px",
                }}
              >
                {[
                  ["TC Map 1", setup.electronics.tc_setting_1],
                  ["TC Map 2", setup.electronics.tc_setting_2],
                  ["Wheelie Ctrl", setup.electronics.wheelie_control],
                  ["Engine Map", setup.electronics.engine_map],
                  ["Anti-Wheelie", setup.electronics.anti_wheelie],
                ].map(([label, val]) => (
                  <div
                    key={label}
                    style={{
                      background: "rgba(176,38,255,0.08)",
                      borderRadius: "8px",
                      padding: "12px",
                      textAlign: "center",
                    }}
                  >
                    <div
                      style={{
                        ...S.heading,
                        fontSize: "22px",
                        color: "#B026FF",
                      }}
                    >
                      {val}
                    </div>
                    <div
                      style={{
                        fontSize: "9px",
                        color: "#666",
                        fontFamily: "Orbitron,sans-serif",
                        letterSpacing: "1px",
                        marginTop: "4px",
                      }}
                    >
                      {label}
                    </div>
                  </div>
                ))}
              </div>
              <p
                style={{
                  ...S.mono,
                  fontSize: "12px",
                  color: "#AAA",
                  lineHeight: 1.7,
                  margin: 0,
                }}
              >
                {setup.electronics.engine_brake_strategy}
              </p>
            </div>
          )}

          {/* Gearing */}
          {setup.gearing && (
            <div style={{ ...S.card, marginBottom: "12px" }}>
              <div
                style={{
                  fontSize: "11px",
                  letterSpacing: "2px",
                  color: "#FF6B00",
                  fontFamily: "Orbitron,sans-serif",
                  marginBottom: "14px",
                }}
              >
                GEAR RATIOS
              </div>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(3,1fr)",
                  gap: "8px",
                  marginBottom: "12px",
                }}
              >
                {[
                  ["Primary", setup.gearing.primary],
                  ["1st Gear", setup.gearing.first],
                  ["Top Gear", setup.gearing.top],
                ].map(([label, val]) => (
                  <div
                    key={label}
                    style={{
                      background: "rgba(255,107,0,0.08)",
                      borderRadius: "8px",
                      padding: "12px",
                      textAlign: "center",
                    }}
                  >
                    <div
                      style={{
                        ...S.heading,
                        fontSize: "20px",
                        color: "#FF6B00",
                      }}
                    >
                      {val}
                    </div>
                    <div
                      style={{
                        fontSize: "9px",
                        color: "#666",
                        fontFamily: "Orbitron,sans-serif",
                        letterSpacing: "1px",
                        marginTop: "4px",
                      }}
                    >
                      {label}
                    </div>
                  </div>
                ))}
              </div>
              <p
                style={{
                  ...S.mono,
                  fontSize: "12px",
                  color: "#AAA",
                  lineHeight: 1.7,
                  margin: 0,
                }}
              >
                {setup.gearing.notes}
              </p>
            </div>
          )}

          {/* Issue Fixes */}
          {setup.issue_fixes && setup.issue_fixes.length > 0 && (
            <div style={{ ...S.card, marginBottom: "12px" }}>
              <div
                style={{
                  fontSize: "11px",
                  letterSpacing: "2px",
                  color: "#E8001D",
                  fontFamily: "Orbitron,sans-serif",
                  marginBottom: "14px",
                }}
              >
                PROBLEM DIAGNOSIS & FIXES
              </div>
              {setup.issue_fixes.map((fix, i) => (
                <div
                  key={i}
                  style={{
                    borderLeft: `3px solid ${fix.priority === "CRITICAL" ? "#E8001D" : fix.priority === "HIGH" ? "#FF6B00" : "#00D4FF"}`,
                    paddingLeft: "14px",
                    marginBottom: "16px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "8px",
                      marginBottom: "6px",
                    }}
                  >
                    <span
                      style={{
                        fontSize: "10px",
                        fontFamily: "Orbitron,sans-serif",
                        letterSpacing: "1px",
                        color:
                          fix.priority === "CRITICAL"
                            ? "#E8001D"
                            : fix.priority === "HIGH"
                              ? "#FF6B00"
                              : "#00D4FF",
                        background: "rgba(255,255,255,0.05)",
                        padding: "2px 8px",
                        borderRadius: "4px",
                      }}
                    >
                      {fix.priority}
                    </span>
                    <span style={{ fontSize: "13px", fontWeight: 600 }}>
                      {fix.issue}
                    </span>
                  </div>
                  <p
                    style={{
                      ...S.mono,
                      fontSize: "12px",
                      color: "#AAA",
                      lineHeight: 1.7,
                      margin: 0,
                    }}
                  >
                    {fix.fix}
                  </p>
                </div>
              ))}
            </div>
          )}

          {/* Coach Notes */}
          {setup.coach_notes && (
            <div
              style={{
                background: "rgba(0,212,255,0.05)",
                border: "1px solid rgba(0,212,255,0.2)",
                borderRadius: "12px",
                padding: "20px",
                marginBottom: "16px",
              }}
            >
              <div
                style={{
                  fontSize: "11px",
                  letterSpacing: "2px",
                  color: "#00D4FF",
                  fontFamily: "Orbitron,sans-serif",
                  marginBottom: "12px",
                }}
              >
                HEAD ENGINEER DEBRIEF
              </div>
              <p
                style={{
                  fontSize: "14px",
                  color: "#C8C8D8",
                  lineHeight: 1.8,
                  margin: 0,
                }}
              >
                {setup.coach_notes}
              </p>
              {setup.lap_time_potential && (
                <div
                  style={{
                    marginTop: "14px",
                    padding: "10px 14px",
                    background: "rgba(0,212,255,0.08)",
                    borderRadius: "8px",
                  }}
                >
                  <span
                    style={{
                      fontSize: "11px",
                      color: "#666",
                      fontFamily: "Orbitron,sans-serif",
                      letterSpacing: "1px",
                    }}
                  >
                    LAP TIME POTENTIAL:{" "}
                  </span>
                  <span
                    style={{
                      fontSize: "13px",
                      color: "#00D4FF",
                      fontFamily: "JetBrains Mono,monospace",
                    }}
                  >
                    {setup.lap_time_potential}
                  </span>
                </div>
              )}
            </div>
          )}

          <button style={{ ...S.btnCyan, width: "100%" }} onClick={saveSetup}>
            <span
              style={{
                display: "flex",
                alignItems: "center",
                gap: "8px",
                justifyContent: "center",
              }}
            >
              <Icon name="save" size={16} color="#0A0A0F" /> Save Setup to
              Garage
            </span>
          </button>
        </div>
      )}
    </div>
  );
};

export default SetupScreen;
